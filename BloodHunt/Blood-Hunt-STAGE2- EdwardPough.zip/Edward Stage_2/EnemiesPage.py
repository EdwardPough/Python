#<<<BloodHunt Enemies>>>
#<<<Importieren wenn nötig>>>



#<<<Klasse>>>
class enemies:
    def __init__(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Goblin>>>
    def enemy_goblin(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 3 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 2 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Orc>>>
    def enemy_orc(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Stone Golem>>>
    def enemy_stonegolem(self):
        self.hitpoints = 200 #Current Amount of HP
        self.maxhp = 200 #Maximum Amount of HP
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy ???>>>
    #def enemy_???(self):
        #self.hitpoints = ++ #Current Amount of HP
        #self.maxhp = ++ #Maximum Amount of HP
        #self.strength = ++ #Damage dealt from enemies
        #self.dodgechance = ++ #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        #self.critchance = ++ #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc


#<<<Klasse Stage2>>>
class enemies_st2:
    def __init__(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.desc = "OH OH FEHLER"
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Spinnling>>>
    def enemy_spiderling(self):
        self.hitpoints = 65 #Current Amount of HP
        self.maxhp = 65 #Maximum Amount of HP
        self.desc = "A huge spiderling crawls from the sea of overgrown vines and thorns."
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 2 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Rosenspinne>>>
    def enemy_rosespider(self):
        self.hitpoints = 90 #Current Amount of HP
        self.maxhp = 90 #Maximum Amount of HP
        self.desc = "A mutated spider with a rosebud growing from its behind...  It is a Lala Barina... What can I say."
        self.strength = 12 #Damage dealt from enemies
        self.dodgechance = 3 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 2 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Kieferspinne>>>
    def enemy_snapspider(self):
        self.hitpoints = 115 #Current Amount of HP
        self.maxhp = 115 #Maximum Amount of HP
        self.desc = "A giant spider with two snapping mandibles covering its chelicerae."
        self.strength = 20 #Damage dealt from enemies
        self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 5 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Kristallpflanze>>>
    def enemy_crystalplant(self):
        self.hitpoints = 200 #Current Amount of HP
        self.maxhp = 200 #Maximum Amount of HP
        self.desc = "A plant sporting leaves as hard as crystal with which it protects its stem."
        self.strength = 7 #Damage dealt from enemies
        self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 0 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Spiegelpflanze>>>
    def enemy_mirrorplant(self):
        self.hitpoints = 150 #Current Amount of HP
        self.maxhp = 150 #Maximum Amount of HP
        self.desc = "A plant with reflecting petals which shine dazzling lights in the eyes of its predators."
        self.strength = 5 #Damage dealt from enemies
        self.dodgechance = 5 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 0 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Verdorberner Gärtner>>>
    def enemy_gardener(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.desc = "A gardener turned by the curse of the Rose Queen."
        self.strength = 15 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Klasse Stage2 Boss>>>
class enemies_st2_b:
    def __init__(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.desc = "OH OH FEHLER"
        self.strength = 10 #Damage dealt from enemies
        self.dodgechance = 1 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 1 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Brutmutter>>>
    def enemy_broodmother(self):
        self.hitpoints = 350 #Current Amount of HP
        self.maxhp = 350 #Maximum Amount of HP
        self.desc = "The beast that spawned all the mutated spiders roaming this greenhouse."
        self.strength = 12 #Damage dealt from enemies
        self.dodgechance = 0 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 4 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc

#<<<Enemy Blutrose>>>
    def enemy_bloodrose(self):
        self.hitpoints = 225 #Current Amount of HP
        self.maxhp = 225 #Maximum Amount of HP
        self.desc = 'A lonely rose said to have been "blessed" by the Queen herself.'
        self.strength = 25 #Damage dealt from enemies
        self.dodgechance = 2 #Determines dodge Chance 1 = 10% to dodge, 4 = 40% etc
        self.critchance = 2 #Determines crit Chance 1 = 10% to dodge, 4 = 40% etc