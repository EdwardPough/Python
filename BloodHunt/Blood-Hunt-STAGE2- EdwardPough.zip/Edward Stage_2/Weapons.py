import Classes
cha = Classes.klassen()
class Weapons:
        def __init__(self):
            self.attack_classic = 10
            self.attack_special = 15
            self.attack_special_manacost = 5
            self.attack_ultimate = 25
            self.attack_ultimate_manacost = 15
                
        def sword(self):
            self.attack_classic = 12 + cha.strength
            self.attack_special = 18 + cha.strength
            self.attack_special_manacost = 5
            self.attack_ultimate = 30 + cha.strength
            self.attack_ultimate_manacost = 15

        def dagger(self):
            self.attack_classic = 10 + cha.dexterity
            self.attack_special = 20 + cha.dexterity
            self.attack_special_manacost = 5
            self.attack_ultimate = 28 + cha.dexterity
            self.attack_ultimate_manacost = 15
            
        def staff(self):
            self.attack_classic = 8 + cha.intelligence
            self.attack_special = 22 + cha.intelligence
            self.attack_special_manacost = 5
            self.attack_ultimate = 32 + cha.intelligence
            self.attack_ultimate_manacost = 15