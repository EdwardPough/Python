#<<<BloodHunt Klassendatei>>>
#<<<Importieren wenn nötig>>>



#<<<Klasse>>>
class klassen:
    def __init__(self):
        self.hitpoints = 100 #Current Amount of HP
        self.maxhp = 100 #Maximum Amount of HP
        self.magicpoints = 100 #Current Amount of MP
        self.maxmp = 100 #Maximum Amount of HP
        self.armor = 10 
        self.strength = 10 #Determines Hit Chances and Damage for Strength-based Weapons?
        self.dexterity = 10 #Determines Hit Chances and Damage for Dexterity-based Weapons and Dodge Chance?
        self.intelligence = 10 #Determines Hit Chances and Damage for Intelligence-based Weapons/Spells and Crit Chance?

#<<<Klasse Krieger>>>
    def klasse_krieger(self):
        self.hitpoints = 150
        self.maxhp = 150 #High
        self.magicpoints = 100
        self.maxmp = 100 #Low
        self.strength = 15 #Medium-High
        self.dexterity = 10 #Medium
        self.intelligence = 5 #Low
        self.armor = 5
        self.dodgechance = 5

#<<<Klasse Magier>>>
    def klasse_magier(self):
        self.hitpoints = 80
        self.maxhp = 80 #Low
        self.magicpoints = 150
        self.maxmp = 150 #High
        self.strength = 5 #Low
        self.dexterity = 8 #Medium-Low
        self.intelligence = 18 #High
        self.armor = 2
        self.dodgechance = 8

#<<<Klasse Assassine>>>
    def klasse_assassine(self):
        self.hitpoints = 100
        self.maxhp = 100 #Medium
        self.magicpoints = 80
        self.maxmp = 80 #Medium-Low
        self.strength = 5 #Low
        self.dexterity = 17 #High
        self.intelligence = 8 #Medium-Low
        self.armor = 3
        self.dodgechance = 15