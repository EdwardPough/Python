import General
import time
import os
#<<<Langsamer Text>>> (Danke David)

def langsamer_text(text, delay = 0.03):
    for x in text:
        print(x, end="", flush=True)
        time.sleep(delay)
    print()

#==============================================STAGE 2=====================================================

def stage2():
    os.system('cls' if os.name == 'nt' else 'clear')
    langsamer_text("Als Ihr die Treppen hinaufsteigt bemerkte er, dass allmählich die gesamten Räume nur noch in Rosen und Ranken überfüllt ist.")
    langsamer_text("Es ähnelt wie bei einem Botanischen Garten, der nur aus Rosen und Blut bestehen. In einer Blutlache vor euch liegen 3 Heiltränken")
    langsamer_text("Kurz nach dem Einstecken der Tränke bemerkt Ihr wie zwischen Blut und Dorn sich etwas auf euch zu bewegt!")
    input("Weiter?")
    General.fight_loop()

stage2()