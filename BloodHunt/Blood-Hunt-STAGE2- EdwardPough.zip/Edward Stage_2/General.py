from importlib.metadata.diagnose import inspect
import os
import Classes 
import Items
import random
import pygame
import time
import sys
import EnemiesPage
import inspect

def langsamer_text(text, delay = 0.03):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()
Round = 1
item = Items.Items()


def main_menu():
    global Menu_active
    while Menu_active == 1:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("====================================================================")
        print("                         BLOOD HUNT")
        print("                  GARDENS OF BLOOD AND ROSES")
        print("====================================================================")
        print("1. Starten")
        print("2. Anleitung")
        print("3. Beenden")
        print("====================================================================")

        wahl = input("Wähle eine Option aus von (1-3): ")
        if wahl == ("1"):
            Menu_active = 0
            starte_spiel()
        elif wahl == ("2"):
            anleitung()
        elif wahl == ("3"):
            langsamer_text("Spiel wird beendet!!")
            pygame.quit()
            sys.exit()
        else:
            print("ungültige Angabe")

def anleitung():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\n=== Anleitung ===\n")
    print("-Kämpfe gegen Gegner.")
    print("-Sammle Items")
    print("-Besiege die Rosenkönigin")
    print()
    input("Drücke ENTER-Taste für zurück. \n")


def starte_spiel():
    os.system('cls' if os.name == 'nt' else 'clear')
    langsamer_text("Aria... einst eine friedliche Stadt voller Musik und Blumen.")
    

    


def reset_mid_fight_values():
    shield = 0

def fight_logic():
    global cha
    global wep
    global item
    global Round
    global klasse_name
    enemies_instance = EnemiesPage.enemies_st2()
    methods = [name for name, method in inspect.getmembers(EnemiesPage.enemies_st2, predicate=inspect.isfunction) 
               if not name.startswith('_')]
    random_enemy = random.choice(methods)
    # Call the random enemy method (this will print which enemy appears)
    getattr(enemies_instance, random_enemy)()
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"Round {Round}.")
    print("=================================================")
    print(f"A wild {random_enemy.replace('enemy_', '').capitalize()} appears!")
    print(enemies_instance.desc)
    print("=================================================")
    
    while cha.hitpoints > 0 and enemies_instance.hitpoints > 0:
        action = input(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP |\n \n/\ The Enemy ({enemies_instance.strength - cha.armor} DMG next Turn) {random_enemy.replace('enemy_', '').capitalize()} has {enemies_instance.hitpoints} HP /\ \n \nChoose your Action: \n| 1. Attack | 2. Shield (for {cha.armor}) | 3. Potion/Items | 4. Exit |").strip().lower()

    #=====================================================================================ATTACK LOGIC=======================================================================================#
        if action == "1" or action == "attack":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP | {klasse_name.capitalize()}\n \n/\ The Enemy {random_enemy.replace('enemy_', '').capitalize()} has {enemies_instance.hitpoints} HP /\ ")
            print(f"\nThe Enemy will attack you for {enemies_instance.strength - cha.armor} damage! \nWhat attack will you do?")
            attack_type = input(f"Choose an Attack!: \n \n| 1 Attack = {wep.attack_classic} DMG | 2 Special Attack = {wep.attack_special} DMG {wep.attack_special_manacost} MP | 3 Ultimate Attack = {wep.attack_ultimate} DMG {wep.attack_ultimate_manacost} MP | ").strip().lower()
            if attack_type == "1" or attack_type == "attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_classic * 2
                    chect = 1
                    cha.magicpoints += 10
                else:
                    damage = wep.attack_classic
                    chect = 0
                    cha.magicpoints += 10
            elif attack_type == "2" or attack_type == "special attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_special * 2
                    chect = 1
                    
                else:
                    damage = wep.attack_special
                    chect = 0
                cha.magicpoints -= wep.attack_special_manacost
            elif attack_type == "3" or attack_type == "ultimate attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_ultimate * 2
                    chect = 1
                else:
                    damage = wep.attack_ultimate
                    chect = 0
                cha.magicpoints -= wep.attack_ultimate_manacost
            if random.randint(1,100) <= enemies_instance.dodgechance * 10:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"===============\n|ENEMY DODGED!|\n===============\nThe {random_enemy.replace('enemy_', '').capitalize()} has dodged your attack!You dealt no damage. Enemy HP is still at {enemies_instance.hitpoints}.")
            else:
                if chect == 0:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print(f"You dealt {damage} damage to the enemy. Enemy HP is now at {enemies_instance.hitpoints}.")
                else:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print(f"===============\n|CRITICAL HIT!|\n===============\nYou're crit dealt {damage} damage to the enemy. Enemy HP is now at {enemies_instance.hitpoints}.")
                    time.sleep(1)
            if enemies_instance.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"You have defeated the {random_enemy.replace('enemy_', '').capitalize()}!")
                cha.hitpoints += 15
                cha.magicpoints += 10
                if cha.hitpoints > cha.maxhp:
                    cha.hitpoints = cha.maxhp
                if cha.magicpoints > cha.maxmp:
                    cha.magicpoints = cha.maxmp
                print(f"You recovered 15 HP and 10 MP. Your current HP is {cha.hitpoints} and MP is {cha.magicpoints}.")
                time.sleep(3)
                if Round < 10:
                    print("Prepare for the next round!")
                    time.sleep(2)
            elif cha.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print("You have been defeated...")
                                    
    #=====================================================================================DEFEND LOGIC=======================================================================================#
        elif action == "2" or action == "defend":
            print("You defend against the enemy's attack!")
            shield = cha.armor
            cha.magicpoints += 10
            os.system('cls' if os.name == 'nt' else 'clear')
    #=====================================================================================ITEM LOGIC=======================================================================================#
        elif action == "3" or action == "potion":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"You use a potion to heal yourself for {item.health_potion_healing}!")
            cha.hitpoints = cha.hitpoints + item.health_potion_healing
            if cha.hitpoints > cha.maxhp:
                cha.hitpoints = cha.maxhp
                cha.magicpoints += 10
            print(f"Your HP is now {cha.hitpoints}.")
        elif action == "exit":
            print("Exiting the fight.")
            Round = 11
            return Round
            
            
        else:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("Invalid action. Please choose again.")
        if enemies_instance.hitpoints > 0:
            if random.randint(1,100) <= cha.dodgechance:
                print(f"===============\n|YOU DODGED!|\n===============\nYou have dodged the {random_enemy.replace('enemy_', '').capitalize()}'s attack!")
            elif enemies_instance.hitpoints > 0:
                if random.randint(1,100) <= enemies_instance.critchance * 10:
                    enemy_damage = enemies_instance.strength * 2 - cha.armor
                    cha.hitpoints -= enemy_damage
                    print(f"===============\n|THE {random_enemy.replace('enemy_', '').capitalize()} HAS CRIT \n===============\n He hit you for {enemy_damage} damage!|\n===============")
                else:
                    enemy_damage = enemies_instance.strength - cha.armor - shield
                    cha.hitpoints -= enemy_damage 
                    shield = 0
                    print(f"The {random_enemy.replace('enemy_', '').capitalize()} attacks you and deals {enemy_damage} damage!")
            
#BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / BOSS FIGHT / 

def fight_logic_boss():
    global cha
    global wep
    global item
    global Round
    global klasse_name
    potions = 3
    enemies_instance = EnemiesPage.enemies_st2_b()
    methods = [name for name, method in inspect.getmembers(EnemiesPage.enemies_st2_b, predicate=inspect.isfunction) 
               if not name.startswith('_')]
    random_enemy = random.choice(methods)
    # Call the random enemy method (this will print which enemy appears)
    getattr(enemies_instance, random_enemy)()
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"Round {Round}.")
    print("=================================================")
    print(f"A wild {random_enemy.replace('enemy_', '').capitalize()} appears!")
    print(enemies_instance.desc)
    print("=================================================")
    
    while cha.hitpoints > 0 and enemies_instance.hitpoints > 0:
        action = input(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP |\n \n/\ The Enemy ({enemies_instance.strength - cha.armor} DMG next Turn) {random_enemy.replace('enemy_', '').capitalize()} has {enemies_instance.hitpoints} HP /\ \n \nChoose your Action: \n| 1. Attack | 2. Shield (for {cha.armor}) | 3. Potion/Items | 4. Exit |").strip().lower()

    #=====================================================================================ATTACK LOGIC=======================================================================================#
        if action == "1" or action == "attack":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"\n|You have {cha.hitpoints} / {cha.maxhp} HP | {cha.magicpoints} / {cha.maxmp} MP | {klasse_name.capitalize()}\n \n/\ The Enemy {random_enemy.replace('enemy_', '').capitalize()} has {enemies_instance.hitpoints} HP /\ ")
            print(f"\nThe Enemy will attack you for {enemies_instance.strength - cha.armor} damage! \nWhat attack will you do?")
            attack_type = input(f"Choose an Attack!: \n \n| 1 Attack = {wep.attack_classic} DMG | 2 Special Attack = {wep.attack_special} DMG {wep.attack_special_manacost} MP | 3 Ultimate Attack = {wep.attack_ultimate} DMG {wep.attack_ultimate_manacost} MP | ").strip().lower()
            if attack_type == "1" or attack_type == "attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_classic * 2
                    chect = 1
                    cha.magicpoints += 10
                else:
                    damage = wep.attack_classic
                    chect = 0
                    cha.magicpoints += 10
            elif attack_type == "2" or attack_type == "special attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_special * 2
                    chect = 1
                    
                else:
                    damage = wep.attack_special
                    chect = 0
                cha.magicpoints -= wep.attack_special_manacost
            elif attack_type == "3" or attack_type == "ultimate attack":
                if random.randint(1,100) <= cha.dexterity * 2:
                    print("Critical Hit!")
                    damage = wep.attack_ultimate * 2
                    chect = 1
                else:
                    damage = wep.attack_ultimate
                    chect = 0
                cha.magicpoints -= wep.attack_ultimate_manacost
            if random.randint(1,100) <= enemies_instance.dodgechance * 10:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"===============\n|ENEMY DODGED!|\n===============\nThe {random_enemy.replace('enemy_', '').capitalize()} has dodged your attack!You dealt no damage. Enemy HP is still at {enemies_instance.hitpoints}.")
            else:
                if chect == 0:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print(f"You dealt {damage} damage to the enemy. Enemy HP is now at {enemies_instance.hitpoints}.")
                else:
                    os.system('cls' if os.name == 'nt' else 'clear')
                    enemies_instance.hitpoints -= damage
                    print(f"===============\n|CRITICAL HIT!|\n===============\nYou're crit dealt {damage} damage to the enemy. Enemy HP is now at {enemies_instance.hitpoints}.")
                    time.sleep(1)
            if enemies_instance.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"You have defeated the {random_enemy.replace('enemy_', '').capitalize()}!")
                cha.hitpoints += 15
                cha.magicpoints += 10
                if cha.hitpoints > cha.maxhp:
                    cha.hitpoints = cha.maxhp
                if cha.magicpoints > cha.maxmp:
                    cha.magicpoints = cha.maxmp
                print(f"You recovered 15 HP and 10 MP. Your current HP is {cha.hitpoints} and MP is {cha.magicpoints}.")
                time.sleep(3)
                if Round < 10:
                    print("Prepare for the next round!")
                    time.sleep(2)
            elif cha.hitpoints <= 0:
                os.system('cls' if os.name == 'nt' else 'clear')
                print("You have been defeated...")
                                    
    #=====================================================================================DEFEND LOGIC=======================================================================================#
        elif action == "2" or action == "defend":
            print("You defend against the enemy's attack!")
            shield = cha.armor
            cha.magicpoints += 10
            os.system('cls' if os.name == 'nt' else 'clear')
    #=====================================================================================ITEM LOGIC=======================================================================================#
        elif action == "3" or action == "potion":
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"You use a potion to heal yourself for {item.health_potion_healing}!")
            cha.hitpoints = cha.hitpoints + item.health_potion_healing
            if cha.hitpoints > cha.maxhp:
                cha.hitpoints = cha.maxhp
                cha.magicpoints += 10
            print(f"Your HP is now {cha.hitpoints}.")
        elif action == "exit":
            print("Exiting the fight.")
            Round = 21
            return Round
            
            
        else:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("Invalid action. Please choose again.")
        if enemies_instance.hitpoints > 0:
            if random.randint(1,100) <= cha.dodgechance:
                print(f"===============\n|YOU DODGED!|\n===============\nYou have dodged the {random_enemy.replace('enemy_', '').capitalize()}'s attack!")
            elif enemies_instance.hitpoints > 0:
                if random.randint(1,100) <= enemies_instance.critchance * 10:
                    enemy_damage = enemies_instance.strength * 2 - cha.armor
                    cha.hitpoints -= enemy_damage
                    print(f"===============\n|THE {random_enemy.replace('enemy_', '').capitalize()} HAS CRIT \n===============\n He hit you for {enemy_damage} damage!|\n===============")
                else:
                    enemy_damage = enemies_instance.strength - cha.armor - shield
                    cha.hitpoints -= enemy_damage 
                    shield = 0
                    print(f"The {random_enemy.replace('enemy_', '').capitalize()} attacks you and deals {enemy_damage} damage!")



def fight_loop():
    global Round
    Round = 11
    while Round < 20:
        fight_logic()
        Round += 1
    Round = 20
    fight_logic_boss()


#=================================START GAME============================================================================================================================================#
#
 #   Menu_active = 1
#
 #   main_menu()
#
 #   Menu_active = 0
#
#==========================MYSTISCHE KLASSENAUSWAHL=========================================================================================================================# ich kann nimmer
cha = Classes.klassen()
kc = 1
klasse_name = ""
while kc == 1:
    print("Welche Klasse wollen sie spielen?")
    klasse = str(input("(Krieger/Magier/Assassine) ")).lower()
    if klasse == "krieger":
        cha.klasse_krieger()
        print("Sie spielen einen Krieger!")
        kc = 2
        klasse_name = "krieger"
    elif klasse == "magier":
        cha.klasse_magier()
        print("Sie spielen einen Magier!")
        kc = 2
        klasse_name = "magier"
    elif klasse == "assassine":
        cha.klasse_assassine()
        print("Sie spielen einen Assasine!")
        kc = 2
        klasse_name = "assasine"
            # Erst die Klasse setzena
            # Dann die Waffe mit den korrekten Stats
    else:
        print("Invalid action. Please choose again.")


        # MUSS NACH DER KLASSENINITIALISIERUNG KOMMEN
class Weapons:
    def __init__(self):
        self.attack_classic = 10
        self.attack_special = 15
        self.attack_ultimate = 25
            
    def sword(self):
        self.attack_classic = 12 + cha.strength
        self.attack_special = 18 + cha.strength
        self.attack_special_manacost = 5
        self.attack_ultimate = 30 + cha.strength
        self.attack_ultimate_manacost = 15

    def dagger(self):
        self.attack_classic = 10 + cha.dexterity
        self.attack_special = 20 + cha.dexterity
        self.attack_special_manacost = 5
        self.attack_ultimate = 28 + cha.dexterity
        self.attack_ultimate_manacost = 15
        
    def staff(self):
        self.attack_classic = 8 + cha.intelligence
        self.attack_special = 22 + cha.intelligence
        self.attack_special_manacost = 5
        self.attack_ultimate = 32 + cha.intelligence
        self.attack_ultimate_manacost = 15

wep = Weapons()
if klasse == "krieger":
    wep.sword()
elif klasse == "magier":
    wep.staff()
elif klasse == "assassine":
    wep.dagger()

#===============================KAMPF============================================================================================================================================#
